GAME TURBO (gaya Xiaomi) - cara build lewat GitHub
1. Upload zip ini ke repo (atau isi foldernya), pastikan .github/workflows/build.yml ikut.
2. Tab Actions -> Build APK -> Run workflow. APK ada di Artifacts: GameTurbo-APK.
3. Pasang APK, buka sekali, beri izin "tampil di atas aplikasi lain" (dan lainnya di Pengaturan Booster > Izin aplikasi).

Isi: lobi (daftar game, Mainkan, Setelan GPU), pengaturan Booster, intro, floating panel Balanced/Wild Boost,
kartu mini saat game dibuka. Mode Wild Boost: layar tetap menyala dan RAM dibersihkan berkala.
Batas: Setelan GPU hanya profil mode (Android tidak mengizinkan app biasa mengubah GPU).
Bypass charging dan refresh rate bergantung HP dan belum tentu bekerja tanpa root.
