package com.gameturbo.app

import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        if (android.os.Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        web = WebView(this)
        web.setBackgroundColor(0xFF000000.toInt())
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.javaScriptEnabled = true
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= 29) web.settings.forceDark = android.webkit.WebSettings.FORCE_DARK_OFF
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.onNativeResume && window.onNativeResume()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onNativeBack&&window.onNativeBack())||false") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    // ---------- izin ----------
    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    private fun startSetting(action: String, withPkg: Boolean) {
        runOnUiThread {
            try {
                val i = Intent(action)
                if (withPkg) i.data = Uri.parse("package:$packageName")
                startActivity(i)
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (_: Exception) {
                }
            }
        }
    }

    inner class Bridge {

        @JavascriptInterface
        fun getGames(): String {
            val arr = JSONArray()
            Games.load(this@MainActivity).forEach { g ->
                arr.put(JSONObject().put("id", g.pkg).put("n", g.label).put("p", g.pkg).put("i", Games.iconB64(g.icon)))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun getApps(): String {
            val shown = Games.gamePackages(this@MainActivity)
            val arr = JSONArray()
            Games.launchable(this@MainActivity).forEach { (p, n) ->
                arr.put(JSONObject().put("p", p).put("n", n).put("g", p in shown))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun addGame(pkg: String) { Games.addManual(this@MainActivity, pkg) }

        @JavascriptInterface
        fun hideGame(pkg: String) { Games.hide(this@MainActivity, pkg) }

        @JavascriptInterface
        fun stats(): String {
            val mi = Booster.memInfo(this@MainActivity)
            return JSONObject()
                .put("ram", Booster.ramPercent(this@MainActivity))
                .put("usedMb", (mi.totalMem - mi.availMem) / 1048576L)
                .put("totalMb", mi.totalMem / 1048576L)
                .put("bat", Booster.batteryPercent(this@MainActivity))
                .put("temp", Booster.batteryTempC(this@MainActivity)?.toDouble() ?: -1.0)
                .put("cpu", Sys.cpuPct())
                .put("cpuGhz", Sys.cpuGhz())
                .put("gpu", Sys.gpuPct())
                .put("gpuMhz", Sys.gpuMhz())
                .put("freeGb", Sys.storageGb().first)
                .put("totalGb", Sys.storageGb().second)
                .put("charging", Booster.charging(this@MainActivity))
                .toString()
        }

        @JavascriptInterface
        fun device(): String {
            val st = Sys.storageGb()
            @Suppress("DEPRECATION")
            val hz = windowManager.defaultDisplay.refreshRate.toDouble()
            val mi = Booster.memInfo(this@MainActivity)
            return JSONObject()
                .put("model", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL)
                .put("android", android.os.Build.VERSION.RELEASE)
                .put("cores", Runtime.getRuntime().availableProcessors())
                .put("hz", hz)
                .put("ramGb", mi.totalMem / 1073741824.0)
                .put("freeGb", st.first)
                .put("totalGb", st.second)
                .toString()
        }

        @JavascriptInterface
        fun xmode(on: Boolean) {
            Games.prefs(this@MainActivity).edit().putBoolean("xmode", on).apply()
        }

        @JavascriptInterface
        fun getX(): Boolean = Games.prefs(this@MainActivity).getBoolean("xmode", false)

        @JavascriptInterface
        fun xset(key: String, on: Boolean) {
            Games.prefs(this@MainActivity).edit().putBoolean(key, on).apply()
        }

        @JavascriptInterface
        fun xget(key: String): Boolean = Games.prefs(this@MainActivity).getBoolean(key, false)

        @JavascriptInterface
        fun setPMode(m: String) {
            Games.prefs(this@MainActivity).edit().putString("pmode", m).apply()
            if (OverlayService.running) OverlayService.start(this@MainActivity, null)
        }

        @JavascriptInterface
        fun pendingCmd(): String {
            val p = Games.prefs(this@MainActivity)
            val c = p.getString("cmd", "") ?: ""
            if (c.isNotEmpty()) p.edit().remove("cmd").apply()
            return c
        }

        @JavascriptInterface
        fun introPref(on: Boolean) {
            Games.prefs(this@MainActivity).edit().putBoolean("intro", on).apply()
        }

        @JavascriptInterface
        fun getIntro(): Boolean = Games.prefs(this@MainActivity).getBoolean("intro", true)

        @JavascriptInterface
        fun introPreview(): Boolean {
            if (!Settings.canDrawOverlays(this@MainActivity)) return false
            val i = Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_INTRO)
            androidx.core.content.ContextCompat.startForegroundService(this@MainActivity, i)
            return true
        }

        @JavascriptInterface
        fun cooling(on: Boolean): String = Sys.cooling(this@MainActivity, on).toString()

        @JavascriptInterface
        fun coolState(): String {
            val p = Games.prefs(this@MainActivity)
            return JSONObject()
                .put("on", p.getBoolean("cool_on", false))
                .put("t0", p.getFloat("cool_t", -1f).toDouble())
                .toString()
        }

        @JavascriptInterface
        fun mini() {
            if (OverlayService.running) {
                startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_MINI))
            }
        }

        @JavascriptInterface
        fun setSide(side: String) {
            Games.prefs(this@MainActivity).edit().putString("side", if (side == "left") "left" else "right").apply()
            if (OverlayService.running) OverlayService.start(this@MainActivity, null)
        }

        @JavascriptInterface
        fun getSide(): String = Games.prefs(this@MainActivity).getString("side", "right") ?: "right"

        @JavascriptInterface
        fun pmode(): String {
            return Games.prefs(this@MainActivity).getString("pmode", "bal") ?: "bal"
        }

        /** Tutup proses background app lain. Return jumlah app yang diproses. */
        @JavascriptInterface
        fun boost(keep: String): Int =
            Booster.boost(this@MainActivity, if (keep.isEmpty()) emptySet() else setOf(keep))

        @JavascriptInterface
        fun launch(pkg: String): Boolean {
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            if (Settings.canDrawOverlays(this@MainActivity)) {
                OverlayService.start(this@MainActivity, pkg)
            }
            runOnUiThread { startActivity(intent) }
            return true
        }

        @JavascriptInterface
        fun perms(): String = JSONObject()
            .put("overlay", Settings.canDrawOverlays(this@MainActivity))
            .put("usage", hasUsage())
            .put("dnd", (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted)
            .put("write", Settings.System.canWrite(this@MainActivity))
            .put("a11y", Sys.a11yEnabled(this@MainActivity))
            .put("running", OverlayService.running)
            .toString()

        @JavascriptInterface
        fun openPerm(which: String) {
            when (which) {
                "overlay" -> startSetting(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true)
                "usage" -> startSetting(Settings.ACTION_USAGE_ACCESS_SETTINGS, false)
                "dnd" -> startSetting(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, false)
                "write" -> startSetting(Settings.ACTION_MANAGE_WRITE_SETTINGS, true)
                "a11y" -> startSetting(Settings.ACTION_ACCESSIBILITY_SETTINGS, false)
            }
        }

        @JavascriptInterface
        fun overlay(on: Boolean): Boolean {
            if (!on) { OverlayService.stop(this@MainActivity); return true }
            if (!Settings.canDrawOverlays(this@MainActivity)) return false
            OverlayService.start(this@MainActivity, null)
            return true
        }

        @JavascriptInterface
        fun openSetting(action: String) { startSetting(action, false) }
    }
}
